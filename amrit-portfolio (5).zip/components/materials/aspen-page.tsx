"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Button } from "@/components/ui/button"
import { ArrowLeft, BookOpen, Video, Download } from "lucide-react"
import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"

export default function AspenPage() {
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  })

  const resources = [
    {
      type: "download",
      icon: <Download className="h-5 w-5 text-primary" />,
      title: "Aspen Plus and Aspen Hysys",
      description: "Download links for Aspen Plus and Aspen Hysys software.",
      link: "https://drive.google.com/drive/folders/1C1MFLmITZAPii0MB2HiIy5GMZO1bYJF3?usp=sharing",
    },
    {
      type: "book",
      icon: <BookOpen className="h-5 w-5 text-primary" />,
      title: "Aspen Book 1",
      description: "Comprehensive guide to using Aspen for chemical process simulation.",
      link: "https://drive.google.com/file/d/1LpqeZZgpAGKJGDUg_REG0SXTLTdKdcX0/view?usp=sharing",
    },
    {
      type: "book",
      icon: <BookOpen className="h-5 w-5 text-primary" />,
      title: "Aspen Book 2",
      description: "Advanced techniques and applications of Aspen in chemical engineering.",
      link: "https://drive.google.com/file/d/1Y86CKZvgLNmys5WVZO16gyJoOr37A7sd/view?usp=sharing",
    },
    {
      type: "video",
      icon: <Video className="h-5 w-5 text-primary" />,
      title: "Aspen Tutorial Playlist 1",
      description: "Video tutorials for learning Aspen Plus and Aspen Hysys.",
      link: "https://youtube.com/playlist?list=PLwdnzlV3ogoWmaPmHqavPktjRTvXcZxb7&si=uG4Cr4utOF24NsDM",
    },
    {
      type: "video",
      icon: <Video className="h-5 w-5 text-primary" />,
      title: "Aspen Tutorial Playlist 2",
      description: "Advanced Aspen tutorials for chemical engineering applications.",
      link: "https://youtube.com/playlist?list=PLgW2fMtaFzDXaQ9Qd9cjL6wgWeX1lcHRi&si=Iu6-APXTNlk8AIRm",
    },
  ]

  const applications = [
    "Process flowsheet development and simulation",
    "Equipment sizing and design",
    "Process optimization and sensitivity analysis",
    "Economic evaluation of chemical processes",
    "Thermodynamic property estimation",
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 },
    },
  }

  return (
    <main className="pt-20 pb-16">
      <div className="container" ref={ref}>
        <div className="mb-8">
          <Button variant="ghost" asChild className="mb-4">
            <Link href="/materials" className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Materials
            </Link>
          </Button>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h1 className="text-3xl font-bold mb-4">Aspen for Chemical Engineering</h1>
            <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Resources for learning and applying Aspen in chemical process simulation and design.
            </p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>Why Learn Aspen?</CardTitle>
                  <CardDescription>
                    Aspen is the industry standard for process simulation and is used by chemical engineers worldwide
                    for process design, optimization, and troubleshooting. Proficiency in Aspen is highly valued by
                    employers in the chemical industry.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <h3 className="font-medium mb-2">Applications in Chemical Engineering:</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    {applications.map((app, index) => (
                      <li key={index}>{app}</li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <Card className="bg-primary/5">
                <CardHeader>
                  <CardTitle>Getting Started</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="mb-4">
                    If you're new to Aspen, we recommend starting with the Aspen Tutorial Playlist 1 and Aspen Book 1.
                    These resources will help you build a solid foundation before moving on to more advanced topics.
                  </p>
                  <p>
                    For advanced applications, Aspen Book 2 and Aspen Tutorial Playlist 2 cover more complex simulations
                    and optimization techniques.
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {resources.map((resource, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Card className="h-full">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="p-2 rounded-full bg-primary/10">{resource.icon}</div>
                    <div>
                      <h3 className="font-medium mb-2">{resource.title}</h3>
                      <p className="text-sm text-muted-foreground mb-4">{resource.description}</p>
                      <Button variant="outline" size="sm" asChild>
                        <a href={resource.link} target="_blank" rel="noopener noreferrer">
                          Access Resource
                        </a>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </main>
  )
}
