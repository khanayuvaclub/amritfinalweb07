"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Download, Eye } from "lucide-react"

export default function BooksPage() {
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  })

  const books = [
    {
      title: "Chemical Process Calculation",
      viewLink: "https://drive.google.com/file/d/1lu54oL0rAUbTnqsDvNrDW0Qqw5YVMblL/view?usp=sharing",
      downloadLink: "https://drive.google.com/uc?export=download&id=1lu54oL0rAUbTnqsDvNrDW0Qqw5YVMblL",
    },
    {
      title: "Fluid Mechanics",
      viewLink: "https://drive.google.com/file/d/15CMVwyJ1vjC-tgojMQIA3z3vPcCdSfSB/preview",
      downloadLink: "https://drive.google.com/uc?export=download&id=15CMVwyJ1vjC-tgojMQIA3z3vPcCdSfSB",
    },
    {
      title: "Chemical Engineering Thermodynamics",
      viewLink: "https://drive.google.com/file/d/19r5VwCULqrR7QLhCqDOQCZLTLhNdsyv4/preview",
      downloadLink: "https://drive.google.com/uc?export=download&id=19_4C1q0bnF8wKBuYUn5uDvH5Q0hKMnrZ",
    },
    {
      title: "Mass Transfer",
      viewLink: "https://drive.google.com/file/d/1mZl4pO53_r8l_1kmlVk1ZewtpUzUj9EO/preview",
      downloadLink: "https://drive.google.com/uc?export=download&id=1mZl4pO53_r8l_1kmlVk1ZewtpUzUj9EO",
    },
    {
      title: "Heat Transfer",
      viewLink: "https://drive.google.com/file/d/1Fr1M5wCtGwmSNXy51E4XSFG9Huetq0mu/preview",
      downloadLink: "https://drive.google.com/uc?export=download&id=1Fr1M5wCtGwmSNXy51E4XSFG9Huetq0mu",
    },
    {
      title: "Chemical Reaction Engineering",
      viewLink: "https://drive.google.com/file/d/1Foqz7qZGekEniVNhtWtv4volwCGywhfC/preview",
      downloadLink: "https://drive.google.com/uc?export=download&id=1Foqz7qZGekEniVNhtWtv4volwCGywhfC",
    },
    {
      title: "Chemical Engineering Design",
      viewLink: "https://drive.google.com/file/d/1JHN57IltWc4jE7c-bLQ_toNL5AAvcE27/preview",
      downloadLink: "https://drive.google.com/uc?export=download&id=1JHN57IltWc4jE7c-bLQ_toNL5AAvcE27",
    },
    {
      title: "Unit Operation",
      viewLink: "https://drive.google.com/file/d/1et4cDLch-lhG69MkS3pWfpqHBTvitjb2/preview",
      downloadLink: "https://drive.google.com/uc?export=download&id=1et4cDLch-lhG69MkS3pWfpqHBTvitjb2",
    },
    {
      title: "Instrumentation and Process Control",
      viewLink: "https://drive.google.com/file/d/1EXMyxBTSzxOQR3NW1cPcXEh4Sct5khkd/preview",
      downloadLink: "https://drive.google.com/uc?export=download&id=1EXMyxBTSzxOQR3NW1cPcXEh4Sct5khkd",
    },
    {
      title: "Chemical Equipment Design",
      viewLink: "https://drive.google.com/file/d/1saYt79S-H7um33300VXeotewchB-NHuD/preview",
      downloadLink: "https://drive.google.com/uc?export=download&id=1saYt79S-H7um33300VXeotewchB-NHuD",
    },
    {
      title: "Welded Tank for Oil Storage",
      viewLink: "https://drive.google.com/file/d/1v3p4C4M8PZrJLovjXV7DrTP4jcxp-wyL/preview",
      downloadLink: "https://drive.google.com/uc?export=download&id=1v3p4C4M8PZrJLovjXV7DrTP4jcxp-wyL",
    },
    {
      title: "Perry's Chemical Engineers Handbook",
      viewLink: "https://drive.google.com/file/d/1HKNUeuKmYdZCL-BYZgWA60HavhRuWBn4/preview",
      downloadLink: "https://drive.google.com/uc?export=download&id=1HKNUeuKmYdZCL-BYZgWA60HavhRuWBn4",
    },
    {
      title: "Transport Phenomenon",
      viewLink: "https://drive.google.com/file/d/1Terj-xwEZPFznejHprcuGCt7ZrbLlklz/preview",
      downloadLink: "https://drive.google.com/uc?export=download&id=1Terj-xwEZPFznejHprcuGCt7ZrbLlklz",
    },
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 },
    },
  }

  return (
    <main className="pt-20 pb-16">
      <div className="container" ref={ref}>
        <div className="mb-8">
          <Button variant="ghost" asChild className="mb-4">
            <Link href="/materials" className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Materials
            </Link>
          </Button>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h1 className="text-3xl font-bold mb-4">Important Books</h1>
            <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Essential textbooks for every chemical engineering student.
            </p>
          </motion.div>
        </div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {books.map((book, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Card className="h-full flex flex-col">
                <CardContent className="p-6 flex-grow">
                  <h3 className="text-lg font-medium">{book.title}</h3>
                </CardContent>
                <CardFooter className="flex gap-2 p-6 pt-0">
                  <Button variant="outline" size="sm" className="flex-1" asChild>
                    <a href={book.viewLink} target="_blank" rel="noopener noreferrer">
                      <Eye className="h-4 w-4 mr-2" />
                      View
                    </a>
                  </Button>
                  <Button variant="default" size="sm" className="flex-1" asChild>
                    <a href={book.downloadLink} target="_blank" rel="noopener noreferrer">
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </a>
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </main>
  )
}
