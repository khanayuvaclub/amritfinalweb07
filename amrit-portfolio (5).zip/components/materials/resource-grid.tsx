"use client"

import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { ChevronDown } from "lucide-react"
import Link from "next/link"
import { Book, FolderOpen, FileCode, Beaker, BarChart3, Compass, CuboidIcon as Cube, Calculator } from "lucide-react"

interface ResourceGridProps {
  inView: boolean
}

const resources = [
  {
    id: "books",
    title: "Important Books",
    icon: <Book className="h-12 w-12 text-blue-600" />,
    href: "/materials/books",
  },
  {
    id: "semester",
    title: "Semester Material",
    icon: <FolderOpen className="h-12 w-12 text-blue-600" />,
    href: "/materials/semester",
  },
  {
    id: "python",
    title: "Python",
    icon: <FileCode className="h-12 w-12 text-blue-600" />,
    href: "/materials/python",
  },
  {
    id: "aspen",
    title: "Aspen",
    icon: <Beaker className="h-12 w-12 text-blue-600" />,
    href: "/materials/aspen",
  },
  {
    id: "matlab",
    title: "MATLAB",
    icon: <BarChart3 className="h-12 w-12 text-blue-600" />,
    href: "/materials/matlab",
  },
  {
    id: "autocad",
    title: "AutoCAD Plant 3D",
    icon: <Compass className="h-12 w-12 text-blue-600" />,
    href: "/materials/autocad",
  },
  {
    id: "solidworks",
    title: "SolidWorks",
    icon: <Cube className="h-12 w-12 text-blue-600" />,
    href: "/materials/solidworks",
  },
  {
    id: "polymath",
    title: "Polymath",
    icon: <Calculator className="h-12 w-12 text-blue-600" />,
    href: "/materials/polymath",
  },
]

export default function ResourceGrid({ inView }: ResourceGridProps) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.7, ease: "easeOut" },
    },
  }

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate={inView ? "visible" : "hidden"}
      className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8"
    >
      {resources.map((resource) => (
        <motion.div key={resource.id} variants={itemVariants}>
          <Link href={resource.href} className="block h-full">
            <Card className="h-full card-hover-effect gradient-border">
              <CardContent className="p-6 flex flex-col items-center justify-center text-center">
                <div className="mb-4 flex justify-center items-center p-4 rounded-full bg-primary/10 animate-float">
                  {resource.icon}
                </div>
                <h3 className="text-xl font-medium mb-4">{resource.title}</h3>
                <ChevronDown className="h-5 w-5 text-muted-foreground animate-bounce" />
              </CardContent>
            </Card>
          </Link>
        </motion.div>
      ))}
    </motion.div>
  )
}
