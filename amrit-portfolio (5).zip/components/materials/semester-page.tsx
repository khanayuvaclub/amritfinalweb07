"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Button } from "@/components/ui/button"
import { ArrowLeft, FolderOpen } from "lucide-react"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"

export default function SemesterPage() {
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  })

  const semesters = [
    {
      name: "First Semester",
      links: [
        {
          name: "Old Curriculum",
          url: "https://drive.google.com/drive/folders/1EVD9f6rW_ik96NSdVetl9mueG97jFgns?usp=sharing",
        },
        {
          name: "New Curriculum",
          url: "https://drive.google.com/drive/folders/1PG9WwAqeb_8huiIVegd66WehU4MJ7V0r?fbclid=IwY2xjawKSPJlleHRuA2FlbQIxMABicmlkETFyWTRIVWpUbjdNN3ZpR2VyAR4Z52Ha7B4Dwp2GhlBvHpIwatL6uM6S4JA39gYdd7n90KAUqQI3tDPRbqFPGA_aem_j_-N5jh_fsLUIOydbcAN_Q",
        },
      ],
    },
    {
      name: "Second Semester",
      links: [
        {
          name: "Old Curriculum",
          url: "https://drive.google.com/drive/folders/1RmdSvc2jTAmPGSHW1Ae0dqHrpuiV8zQv?usp=sharing",
        },
        {
          name: "New Curriculum",
          url: "https://drive.google.com/drive/folders/1eqapi8FnCrvvkilATJJRPCjh5qC60duZ?fbclid=IwY2xjawKSPJlleHRuA2FlbQIxMABicmlkETFyWTRIVWpUbjdNN3ZpR2VyAR4Z52Ha7B4Dwp2GhlBvHpIwatL6uM6S4JA39gYdd7n90KAUqQI3tDPRbqFPGA_aem_j_-N5jh_fsLUIOydbcAN_Q",
        },
      ],
    },
    {
      name: "Third Semester",
      links: [
        {
          name: "Old Curriculum",
          url: "https://drive.google.com/drive/folders/1iT3zNv9iS3vIimLXM3r8jvU3y8T-lt8T?usp=sharing",
        },
        {
          name: "New Curriculum",
          url: "https://drive.google.com/drive/folders/1eqapi8FnCrvvkilATJJRPCjh5qC60duZ?fbclid=IwY2xjawKSPJlleHRuA2FlbQIxMABicmlkETFyWTRIVWpUbjdNN3ZpR2VyAR4Z52Ha7B4Dwp2GhlBvHpIwatL6uM6S4JA39gYdd7n90KAUqQI3tDPRbqFPGA_aem_j_-N5jh_fsLUIOydbcAN_Q",
        },
      ],
    },
    {
      name: "Fourth Semester",
      links: [
        {
          name: "Old Curriculum",
          url: "https://drive.google.com/drive/folders/1zfJqT2ak4h77Yl-UMXjvGDWekyL1x_sg?usp=sharing",
        },
        {
          name: "New Curriculum",
          url: "https://drive.google.com/drive/folders/1eqapi8FnCrvvkilATJJRPCjh5qC60duZ?fbclid=IwY2xjawKSPJlleHRuA2FlbQIxMABicmlkETFyWTRIVWpUbjdNN3ZpR2VyAR4Z52Ha7B4Dwp2GhlBvHpIwatL6uM6S4JA39gYdd7n90KAUqQI3tDPRbqFPGA_aem_j_-N5jh_fsLUIOydbcAN_Q",
        },
      ],
    },
    {
      name: "Fifth Semester",
      links: [
        {
          name: "Old Curriculum",
          url: "https://drive.google.com/drive/folders/11Ii89daudscfp3K8CzPrC244hSvBYH2q?usp=sharing",
        },
        {
          name: "New Curriculum",
          url: "https://drive.google.com/drive/folders/1eqapi8FnCrvvkilATJJRPCjh5qC60duZ?fbclid=IwY2xjawKSPJlleHRuA2FlbQIxMABicmlkETFyWTRIVWpUbjdNN3ZpR2VyAR4Z52Ha7B4Dwp2GhlBvHpIwatL6uM6S4JA39gYdd7n90KAUqQI3tDPRbqFPGA_aem_j_-N5jh_fsLUIOydbcAN_Q",
        },
      ],
    },
    {
      name: "Sixth Semester",
      links: [
        {
          name: "Old Curriculum",
          url: "https://drive.google.com/drive/folders/1fbO_No-Xv_hqBjQnaqePIwhYsKmrCzVT?usp=sharing",
        },
        {
          name: "New Curriculum",
          url: "https://drive.google.com/drive/folders/1eqapi8FnCrvvkilATJJRPCjh5qC60duZ?fbclid=IwY2xjawKSPJlleHRuA2FlbQIxMABicmlkETFyWTRIVWpUbjdNN3ZpR2VyAR4Z52Ha7B4Dwp2GhlBvHpIwatL6uM6S4JA39gYdd7n90KAUqQI3tDPRbqFPGA_aem_j_-N5jh_fsLUIOydbcAN_Q",
        },
      ],
    },
    {
      name: "Seventh Semester",
      links: [
        {
          name: "Old Curriculum",
          url: "https://drive.google.com/drive/folders/1dxAjcQLPrG0qbpBHxv7qG7TMLS4e1cXC?usp=sharing",
        },
        {
          name: "New Curriculum",
          url: "https://drive.google.com/drive/folders/1eqapi8FnCrvvkilATJJRPCjh5qC60duZ?fbclid=IwY2xjawKSPJlleHRuA2FlbQIxMABicmlkETFyWTRIVWpUbjdNN3ZpR2VyAR4Z52Ha7B4Dwp2GhlBvHpIwatL6uM6S4JA39gYdd7n90KAUqQI3tDPRbqFPGA_aem_j_-N5jh_fsLUIOydbcAN_Q",
        },
      ],
    },
    {
      name: "Eighth Semester",
      links: [
        {
          name: "Old Curriculum",
          url: "https://drive.google.com/drive/folders/1A3wtP2BB5BTG5-nei-bOHzK5ROhQ_5Id?usp=sharing",
        },
        {
          name: "New Curriculum",
          url: "https://drive.google.com/drive/folders/1eqapi8FnCrvvkilATJJRPCjh5qC60duZ?fbclid=IwY2xjawKSPJlleHRuA2FlbQIxMABicmlkETFyWTRIVWpUbjdNN3ZpR2VyAR4Z52Ha7B4Dwp2GhlBvHpIwatL6uM6S4JA39gYdd7n90KAUqQI3tDPRbqFPGA_aem_j_-N5jh_fsLUIOydbcAN_Q",
        },
      ],
    },
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 },
    },
  }

  return (
    <main className="pt-20 pb-16">
      <div className="container" ref={ref}>
        <div className="mb-8">
          <Button variant="ghost" asChild className="mb-4">
            <Link href="/materials" className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Materials
            </Link>
          </Button>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h1 className="text-3xl font-bold mb-4">Semester Materials</h1>
            <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Comprehensive resources organized by semester for chemical engineering curriculum.
            </p>
          </motion.div>
        </div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {semesters.map((semester, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Card className="h-full">
                <CardContent className="p-6">
                  <h3 className="text-xl font-medium mb-6">{semester.name}</h3>
                  <div className="space-y-4">
                    {semester.links.map((link, linkIndex) => (
                      <Button key={linkIndex} variant="outline" className="w-full justify-start" asChild>
                        <a href={link.url} target="_blank" rel="noopener noreferrer">
                          <FolderOpen className="h-4 w-4 mr-2" />
                          Open {link.name}
                        </a>
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </main>
  )
}
