"use client"

import { motion } from "framer-motion"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Button } from "@/components/ui/button"
import { ExternalLink } from "lucide-react"
import { semesterMaterials } from "@/data/semester-materials"

interface SemesterMaterialsProps {
  inView: boolean
}

export default function SemesterMaterials({ inView }: SemesterMaterialsProps) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 },
    },
  }

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.5 }}
        className="text-center mb-8"
      >
        <h2 className="text-2xl font-bold mb-4">Semester-wise Study Materials</h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Comprehensive resources organized by semester for chemical engineering curriculum.
        </p>
      </motion.div>

      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate={inView ? "visible" : "hidden"}
        className="max-w-3xl mx-auto"
      >
        <Accordion type="single" collapsible className="w-full">
          {semesterMaterials.map((semester, index) => (
            <motion.div key={index} variants={itemVariants}>
              <AccordionItem value={`semester-${index}`}>
                <AccordionTrigger className="text-lg font-medium hover:no-underline">{semester.name}</AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-4 py-2">
                    {semester.resources.map((resource, resourceIndex) => (
                      <div key={resourceIndex} className="flex justify-between items-center">
                        <span className="text-muted-foreground">{resource.name}</span>
                        <Button variant="outline" size="sm" asChild>
                          <a href={resource.link} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="h-4 w-4 mr-2" />
                            Access
                          </a>
                        </Button>
                      </div>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </motion.div>
    </div>
  )
}
