"use client"

import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { ExternalLink, Download, BookOpen, Video } from "lucide-react"
import { softwareResources } from "@/data/software-resources"

interface SoftwareResourcesProps {
  inView: boolean
}

export default function SoftwareResources({ inView }: SoftwareResourcesProps) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 },
    },
  }

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.5 }}
        className="text-center mb-8"
      >
        <h2 className="text-2xl font-bold mb-4">Software Resources for Chemical Engineers</h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Essential software tools and learning resources for modern chemical engineering.
        </p>
      </motion.div>

      <Tabs defaultValue="python" className="w-full">
        <TabsList className="flex flex-wrap justify-center gap-2 mb-8">
          {softwareResources.map((resource, index) => (
            <TabsTrigger key={index} value={resource.id} className="px-4 py-2">
              {resource.name}
            </TabsTrigger>
          ))}
        </TabsList>

        {softwareResources.map((resource, index) => (
          <TabsContent key={index} value={resource.id}>
            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate={inView ? "visible" : "hidden"}
              className="grid grid-cols-1 md:grid-cols-2 gap-6"
            >
              <motion.div variants={itemVariants}>
                <Card className="h-full">
                  <CardHeader>
                    <CardTitle>About {resource.name}</CardTitle>
                    <CardDescription>{resource.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {resource.resources.map((item, itemIndex) => (
                      <div key={itemIndex} className="border-b pb-4 last:border-0 last:pb-0">
                        <h4 className="font-medium mb-2 flex items-center">
                          {item.type === "download" && <Download className="h-4 w-4 mr-2 text-primary" />}
                          {item.type === "book" && <BookOpen className="h-4 w-4 mr-2 text-primary" />}
                          {item.type === "video" && <Video className="h-4 w-4 mr-2 text-primary" />}
                          {item.name}
                        </h4>
                        <p className="text-sm text-muted-foreground mb-2">{item.description}</p>
                        <Button variant="outline" size="sm" asChild>
                          <a href={item.link} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="h-4 w-4 mr-2" />
                            Access Resource
                          </a>
                        </Button>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div variants={itemVariants}>
                <Card className="h-full bg-muted/30">
                  <CardHeader>
                    <CardTitle>Why Learn {resource.name}?</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <p>{resource.whyLearn}</p>
                      <h4 className="font-medium">Applications in Chemical Engineering:</h4>
                      <ul className="list-disc pl-5 space-y-2">
                        {resource.applications.map((app, appIndex) => (
                          <li key={appIndex}>{app}</li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </motion.div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
