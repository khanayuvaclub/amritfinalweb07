"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Button } from "@/components/ui/button"
import { ArrowLeft, BookOpen, Video, Download } from "lucide-react"
import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"

export default function PythonPage() {
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  })

  const resources = [
    {
      type: "book",
      icon: <BookOpen className="h-5 w-5 text-primary" />,
      title: "Python Books Collection",
      description: "A comprehensive collection of Python books for chemical engineers.",
      link: "https://drive.google.com/drive/folders/1JAjsAsDgxq9bYrJ-1RDsxonDdg770NZ1?usp=sharing",
    },
    {
      type: "download",
      icon: <Download className="h-5 w-5 text-primary" />,
      title: "Python Workshop Materials",
      description: "Workshop materials for learning Python in chemical engineering.",
      link: "https://drive.google.com/drive/folders/1ti5e3lslMOH9tMCvz2zwDsc1PgJ17VfR?usp=drive_link",
    },
    {
      type: "video",
      icon: <Video className="h-5 w-5 text-primary" />,
      title: "Python Tutorial - Part 1",
      description: "Video tutorial on Python basics for chemical engineers.",
      link: "https://youtu.be/nLRL_NcnK-4?si=8_LLRG-fky_urLpt",
    },
    {
      type: "video",
      icon: <Video className="h-5 w-5 text-primary" />,
      title: "Python Tutorial - Part 2",
      description: "Advanced Python concepts for chemical engineering applications.",
      link: "https://youtube.com/playlist?list=PLkdGijFCNuVnGxo-1fSNcdHh5gZc17oRM&si=gTGTdYXIk9tuvTPH",
    },
    {
      type: "video",
      icon: <Video className="h-5 w-5 text-primary" />,
      title: "TensorFlow Tutorial - Part 1",
      description: "Introduction to TensorFlow for machine learning in chemical engineering.",
      link: "https://youtu.be/tpCFfeUEGs8?si=dmt1aNF4zOxdLOzN",
    },
    {
      type: "video",
      icon: <Video className="h-5 w-5 text-primary" />,
      title: "TensorFlow Tutorial - Part 2",
      description: "Advanced TensorFlow applications in chemical engineering.",
      link: "https://youtu.be/ZUKz4125WNI?si=Ngt0cLHgjqHPTbl2",
    },
  ]

  const applications = [
    "Process simulation and optimization",
    "Data analysis of experimental results",
    "Machine learning for predictive modeling",
    "Automation of repetitive calculations",
    "Creating interactive visualizations of chemical processes",
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 },
    },
  }

  return (
    <main className="pt-20 pb-16">
      <div className="container" ref={ref}>
        <div className="mb-8">
          <Button variant="ghost" asChild className="mb-4">
            <Link href="/materials" className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Materials
            </Link>
          </Button>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h1 className="text-3xl font-bold mb-4">Python for Chemical Engineering</h1>
            <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Resources for learning and applying Python in chemical engineering applications.
            </p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>Why Learn Python?</CardTitle>
                  <CardDescription>
                    Python has become an essential tool for chemical engineers due to its simplicity, versatility, and
                    powerful libraries for scientific computing, data analysis, and machine learning.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <h3 className="font-medium mb-2">Applications in Chemical Engineering:</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    {applications.map((app, index) => (
                      <li key={index}>{app}</li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <Card className="bg-primary/5">
                <CardHeader>
                  <CardTitle>Getting Started</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="mb-4">
                    If you're new to Python, we recommend starting with the Python Tutorial Part 1 and the Python
                    Workshop Materials. These resources will help you build a solid foundation before moving on to more
                    advanced topics.
                  </p>
                  <p>
                    For chemical engineering applications, the Python Books Collection contains specialized resources
                    focused on numerical methods, data analysis, and process simulation.
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {resources.map((resource, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Card className="h-full">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="p-2 rounded-full bg-primary/10">{resource.icon}</div>
                    <div>
                      <h3 className="font-medium mb-2">{resource.title}</h3>
                      <p className="text-sm text-muted-foreground mb-4">{resource.description}</p>
                      <Button variant="outline" size="sm" asChild>
                        <a href={resource.link} target="_blank" rel="noopener noreferrer">
                          Access Resource
                        </a>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </main>
  )
}
