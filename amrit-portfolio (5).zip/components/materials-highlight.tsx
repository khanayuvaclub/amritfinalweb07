"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Book, FolderOpen, FileCode, Beaker } from "lucide-react"
import Link from "next/link"

export default function MaterialsHighlight() {
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0.05,
  })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.7, ease: "easeOut" },
    },
  }

  const resources = [
    {
      title: "Important Books",
      icon: <Book className="h-12 w-12 text-blue-600" />,
      href: "/materials/books",
    },
    {
      title: "Semester Material",
      icon: <FolderOpen className="h-12 w-12 text-blue-600" />,
      href: "/materials/semester",
    },
    {
      title: "Python",
      icon: <FileCode className="h-12 w-12 text-blue-600" />,
      href: "/materials/python",
    },
    {
      title: "Aspen",
      icon: <Beaker className="h-12 w-12 text-blue-600" />,
      href: "/materials/aspen",
    },
  ]

  return (
    <>
      {/* Section divider */}
      <div className="section-divider">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" preserveAspectRatio="none">
          <path
            fill="currentColor"
            fillOpacity="0.05"
            d="M0,224L48,213.3C96,203,192,181,288,181.3C384,181,480,203,576,224C672,245,768,267,864,250.7C960,235,1056,181,1152,165.3C1248,149,1344,171,1392,181.3L1440,192L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
          ></path>
        </svg>
      </div>

      <section id="materials-highlight" className="py-20 bg-grid" ref={ref}>
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7, ease: "easeOut" }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-bold mb-4 gradient-text inline-block">Engineering Materials</h2>
            <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Access a curated collection of resources for chemical engineering students.
            </p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate={inView ? "visible" : "hidden"}
            className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8 mb-12"
          >
            {resources.map((resource, index) => (
              <motion.div key={index} variants={itemVariants}>
                <Link href={resource.href} className="block h-full">
                  <Card className="h-full card-hover-effect gradient-border">
                    <CardContent className="p-6 flex flex-col items-center justify-center text-center">
                      <div className="mb-4 flex justify-center items-center p-4 rounded-full bg-primary/10 animate-float">
                        {resource.icon}
                      </div>
                      <h3 className="text-xl font-medium">{resource.title}</h3>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </motion.div>

          <div className="text-center">
            <Button size="lg" className="bg-primary hover:bg-primary/90 animate-pulse-glow" asChild>
              <Link href="/materials">Explore All Resources</Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  )
}
