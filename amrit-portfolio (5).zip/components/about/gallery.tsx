"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Image from "next/image"
import { X } from "lucide-react"

const galleryImages = [
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/fbProfile.jpg-Y9NlwLYJyDPFkjDqB0pF4LrXwzjkRH.jpeg",
    alt: "Temple visit",
    caption: "Visiting a historical Pashupatinath temple in Kathmandu",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Football-lDOz12TV7imCNTPYQgBLnBZRht5zDT.jpeg",
    alt: "Football team",
    caption: "With my football team at the university sports event",
  },
  {
    src: "https://scontent.fktm23-1.fna.fbcdn.net/v/t39.30808-6/474774259_1788738491976222_5197470622812489023_n.jpg?_nc_cat=111&ccb=1-7&_nc_sid=127cfc&_nc_ohc=kvo6ufMPyzQQ7kNvwFqH-mN&_nc_oc=AdmBspgyIJkh9Z3UW1bypg_v7SQ8ytbzk77NxiFSjFrgsKlzfwf1AHxpt8MJGa_cOag&_nc_zt=23&_nc_ht=scontent.fktm23-1.fna&_nc_gid=brDsSJY0YHXa1ofOTr8W5Q&oh=00_AfJWZlI-BHgROWmMKzY-YGiNCG0k-fx40TCpVB7INVVXyA&oe=682AB77B",
    alt: "Ministry project",
    caption: "Working on a project at the Ministry of water supply and sanitation",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Gap-Ce62rbPgJ7wyXRRMuwjqq2BirVXmlH.jpeg",
    alt: "Gapians",
    caption: "GAP Picnic Programme",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/BchGuyss-QZMWmbMazmFIAYZVSl3I1BiDmeEat3.jpeg",
    alt: "Field trip",
    caption: "With Chemical Guyss",
  },
  /*
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/tinahukhola.jpg-0HtsxtsBfTXPA1kbBMDIcByLUPqtX5.jpeg",
    alt: "swimming",
    caption: "Tinahu river Butwal",
  },
  */
]

interface GalleryProps {
  inView: boolean
}

export default function Gallery({ inView }: GalleryProps) {
  const [selectedImage, setSelectedImage] = useState<number | null>(null)

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { scale: 0.8, opacity: 0 },
    visible: {
      scale: 1,
      opacity: 1,
      transition: { duration: 0.5 },
    },
  }

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.5 }}
        className="text-center mb-8"
      >
        <p className="text-muted-foreground max-w-2xl mx-auto">
          A visual journey through my academic and research experiences.
        </p>
      </motion.div>

      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate={inView ? "visible" : "hidden"}
        className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4"
      >
        {galleryImages.map((image, index) => (
          <motion.div
            key={index}
            variants={itemVariants}
            className="relative aspect-square overflow-hidden rounded-md cursor-pointer group"
            onClick={() => setSelectedImage(index)}
          >
            <Image
              src={image.src || "/placeholder.svg"}
              alt={image.alt}
              fill
              className="object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors duration-300 flex items-end">
              <div className="p-4 w-full translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                <p className="text-white text-sm font-medium">{image.caption}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </motion.div>

      <AnimatePresence>
        {selectedImage !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
            onClick={() => setSelectedImage(null)}
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              className="relative max-w-4xl w-full max-h-[90vh] flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                className="absolute top-2 right-2 z-10 p-2 bg-black/50 rounded-full text-white"
                onClick={() => setSelectedImage(null)}
              >
                <X className="h-6 w-6" />
              </button>
              <div className="relative w-full h-[70vh]">
                <Image
                  src={galleryImages[selectedImage].src || "/placeholder.svg"}
                  alt={galleryImages[selectedImage].alt}
                  fill
                  className="object-contain"
                />
              </div>
              <div className="bg-background p-4 rounded-b-md">
                <p className="font-medium">{galleryImages[selectedImage].alt}</p>
                <p className="text-muted-foreground mt-1">{galleryImages[selectedImage].caption}</p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
