"use client"

import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const technicalSkills = [
  { name: "Python", level: 80 },
  { name: "MATLAB", level: 75 },
  { name: "Machine Learning", level: 80 },
  { name: "Process Simulation", level: 75 },
  { name: "TensorFlow", level: 70 },
  { name: "Ms-Office", level: 85 },
]

const engineeringSkills = [
  { name: "Chemical Process Design", level: 85 },
  { name: "Wastewater Treatment", level: 90 },
  { name: "Extraction Techniques", level: 80 },
  { name: "Risk Assessment", level: 75 },
  { name: "Sustainable Engineering", level: 85 },
  { name: "Laboratory Techniques", level: 90 },
]

const professionalSkills = [
  { name: "Research & Development", level: 85 },
  { name: "Technical Writing", level: 80 },
  { name: "Project Management", level: 85 },
  { name: "Team Leadership", level: 80 },
  { name: "Problem Solving", level: 90 },
  { name: "Public Speaking", level: 75 },
]

interface SkillsProps {
  inView: boolean
}

export default function Skills({ inView }: SkillsProps) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { width: 0, opacity: 0 },
    visible: (level: number) => ({
      width: `${level}%`,
      opacity: 1,
      transition: { duration: 0.8, ease: "easeOut" },
    }),
  }

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.5 }}
        className="text-center mb-8"
      >
        <p className="text-muted-foreground max-w-2xl mx-auto">
          My technical, engineering, and professional competencies.
        </p>
      </motion.div>

      <Card>
        <CardContent className="p-6">
          <Tabs defaultValue="technical" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="technical">Technical</TabsTrigger>
              <TabsTrigger value="engineering">Engineering</TabsTrigger>
              <TabsTrigger value="professional">Professional</TabsTrigger>
            </TabsList>

            <TabsContent value="technical" className="mt-6">
              <motion.div
                variants={containerVariants}
                initial="hidden"
                animate={inView ? "visible" : "hidden"}
                className="space-y-4"
              >
                {technicalSkills.map((skill, index) => (
                  <div key={index} className="space-y-1">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">{skill.name}</span>
                      <span className="text-sm text-muted-foreground">{skill.level}%</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <motion.div
                        custom={skill.level}
                        variants={itemVariants}
                        className="h-full bg-primary rounded-full"
                      ></motion.div>
                    </div>
                  </div>
                ))}
              </motion.div>
            </TabsContent>

            <TabsContent value="engineering" className="mt-6">
              <motion.div
                variants={containerVariants}
                initial="hidden"
                animate={inView ? "visible" : "hidden"}
                className="space-y-4"
              >
                {engineeringSkills.map((skill, index) => (
                  <div key={index} className="space-y-1">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">{skill.name}</span>
                      <span className="text-sm text-muted-foreground">{skill.level}%</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <motion.div
                        custom={skill.level}
                        variants={itemVariants}
                        className="h-full bg-primary rounded-full"
                      ></motion.div>
                    </div>
                  </div>
                ))}
              </motion.div>
            </TabsContent>

            <TabsContent value="professional" className="mt-6">
              <motion.div
                variants={containerVariants}
                initial="hidden"
                animate={inView ? "visible" : "hidden"}
                className="space-y-4"
              >
                {professionalSkills.map((skill, index) => (
                  <div key={index} className="space-y-1">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">{skill.name}</span>
                      <span className="text-sm text-muted-foreground">{skill.level}%</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <motion.div
                        custom={skill.level}
                        variants={itemVariants}
                        className="h-full bg-primary rounded-full"
                      ></motion.div>
                    </div>
                  </div>
                ))}
              </motion.div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
