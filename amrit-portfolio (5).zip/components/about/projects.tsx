"use client"

import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ExternalLink, Github } from "lucide-react"
import Image from "next/image"

const projects = [
  {
    title: "Water Quality Analysis",
    description:
      "Developed a comprehensive analysis system for water quality parameters using IoT sensors and machine learning algorithms to predict contamination levels.",
    year: "2023",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Laboratory.jpg-awYFe7pO6V9oeTIXEsQ8T1wGayKmdg.jpeg",
    tags: ["Python", "ML", "IoT", "Data Analysis"],
    demoLink: "#",
    codeLink: "#",
  },
  {
    title: "Chemical Accident Risk Measure",
    description:
      "Created a risk assessment framework for chemical plants that identifies potential hazards and suggests preventive measures using predictive modeling.",
    year: "2023",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG-d00aae71c926c48834b6044bc6c5a52c-V.jpg-xXs8ItwKBGC4krgCAHMU86mUDTKYnd.jpeg",
    tags: ["Risk Analysis", "Simulation", "Safety Engineering"],
    demoLink: "#",
    codeLink: "#",
  },
  {
    title: "Wastewater Prediction Using RNN",
    description:
      "Implemented a Recurrent Neural Network model to predict wastewater quality parameters and optimize treatment processes in real-time.",
    year: "2024",
    image:
      "https://media.licdn.com/dms/image/v2/D5622AQE45et8RXDBHA/feedshare-shrink_2048_1536/B56ZbPInBwHUAs-/0/1747231863957?e=1750291200&v=beta&t=qR0RLrd4MBhUadncvrF7IwRC6e1hqvLtG8eAUWdurK0",
    tags: ["Deep Learning", "RNN", "TensorFlow", "Time Series"],
    demoLink: "#",
    codeLink: "#",
  },
  {
    title: "Herbal Extraction Research",
    description:
      "Ongoing research on eco-friendly extraction methods for medicinal herbs native to Nepal, focusing on maximizing yield while minimizing environmental impact.",
    year: "2025-Present",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Plantation.jpg-txXD1wJLycX9iNfhuuGxyu96F3CSHJ.jpeg",
    tags: ["Green Chemistry", "Extraction", "Optimization"],
    demoLink: "#",
    codeLink: "#",
  },
]

interface ProjectsProps {
  inView: boolean
}

export default function Projects({ inView }: ProjectsProps) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.7, ease: "easeOut" },
    },
  }

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.7, ease: "easeOut" }}
        className="text-center mb-8"
      >
        <p className="text-muted-foreground max-w-2xl mx-auto">
          A collection of research projects and applications I've developed in the fields of chemical engineering and
          machine learning.
        </p>
      </motion.div>

      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate={inView ? "visible" : "hidden"}
        className="grid grid-cols-1 md:grid-cols-2 gap-8"
      >
        {projects.map((project, index) => (
          <motion.div key={index} variants={itemVariants}>
            <Card className="h-full overflow-hidden group card-hover-effect">
              <div className="relative h-48 overflow-hidden">
                <Image
                  src={project.image || "/placeholder.svg"}
                  alt={project.title}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div className="absolute top-2 right-2 bg-background/80 backdrop-blur-sm text-xs font-medium py-1 px-2 rounded shadow-md">
                  {project.year}
                </div>
              </div>
              <CardHeader>
                <CardTitle className="text-xl">{project.title}</CardTitle>
                <CardDescription>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {project.tags.map((tag, tagIndex) => (
                      <span
                        key={tagIndex}
                        className="bg-primary/10 text-primary text-xs px-2 py-1 rounded-full transition-all duration-300 hover:bg-primary/20"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{project.description}</p>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" size="sm" className="group" asChild>
                  <a href={project.demoLink} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="h-4 w-4 mr-2 transition-transform duration-300 group-hover:translate-y-[-2px]" />
                    Demo
                  </a>
                </Button>
                <Button variant="outline" size="sm" className="group" asChild>
                  <a href={project.codeLink} target="_blank" rel="noopener noreferrer">
                    <Github className="h-4 w-4 mr-2 transition-transform duration-300 group-hover:scale-110" />
                    Code
                  </a>
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </motion.div>
    </div>
  )
}
