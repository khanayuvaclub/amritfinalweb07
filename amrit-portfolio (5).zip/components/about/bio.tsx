"use client"

import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { GraduationCap, Briefcase } from "lucide-react"
import Image from "next/image"

const timelineItems = [
  {
    year: "2021 - Present",
    title: "B.E. in Chemical Engineering",
    description: "Pulchowk Campus, Institute of Engineering, Tribhuvan University",
    icon: <GraduationCap className="h-5 w-5" />,
  },
  {
    year: "2023",
    title: "Research",
    description: "Water Quality Analysis Project, Department of Applied sciences and Chemical Engineering",
    icon: <Briefcase className="h-5 w-5" />,
  },
  {
    year: "2024",
    title: "ML Project",
    description: "Wastewater Prediction Using RNN, AI Research Lab",
    icon: <Briefcase className="h-5 w-5" />,
  },
]

interface BioProps {
  inView: boolean
}

export default function Bio({ inView }: BioProps) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 },
    },
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={inView ? { opacity: 1, x: 0 } : {}}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <Card className="h-full">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-6 items-center mb-6">
              <div className="relative w-32 h-32 rounded-full overflow-hidden border-2 border-primary/20 flex-shrink-0">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/fbProfile.jpg-Y9NlwLYJyDPFkjDqB0pF4LrXwzjkRH.jpeg"
                  alt="Amrit Khanal"
                  fill
                  className="object-cover"
                />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Who I Am</h3>
                <p className="text-muted-foreground">
                  I am a Chemical Engineering undergraduate with a passion for applying machine learning techniques to
                  solve complex environmental challenges.
                </p>
              </div>
            </div>
            <p className="text-muted-foreground mb-4">
              My research focuses on sustainable solutions for wastewater treatment and chemical process optimization.
              With a strong foundation in both engineering principles and data science, I strive to develop innovative
              approaches that bridge the gap between traditional chemical engineering and cutting-edge computational
              methods.
            </p>
            <p className="text-muted-foreground">
              I am particularly interested in creating eco-friendly solutions that address real-world problems in Nepal
              and beyond.
            </p>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate={inView ? "visible" : "hidden"}
        className="relative"
      >
        <div className="absolute left-4 top-0 h-full w-0.5 bg-border"></div>
        {timelineItems.map((item, index) => (
          <motion.div key={index} variants={itemVariants} className="relative pl-10 pb-8 last:pb-0">
            <div className="absolute left-0 top-1 w-8 h-8 bg-background rounded-full border border-border flex items-center justify-center z-10">
              {item.icon}
            </div>
            <div className="mb-1 text-sm text-muted-foreground">{item.year}</div>
            <h4 className="text-lg font-semibold mb-1">{item.title}</h4>
            <p className="text-muted-foreground">{item.description}</p>
          </motion.div>
        ))}
      </motion.div>
    </div>
  )
}
