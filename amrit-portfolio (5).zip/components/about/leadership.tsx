"use client"

import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Edit3, Users, Award } from "lucide-react"
import Image from "next/image"

const leadershipRoles = [
  {
  title: "Editor & Chief",
  organization: "SSOCHE Annual Magazine",
  period: "2024 - Present",
  description: "Leading the editorial process, coordinating with contributors, and overseeing the publication of the annual magazine (Chemical Horizons) for the Society of Chemical Engineers (SSOCHE).",
  icon: <Edit3 className="h-10 w-10 text-primary" />,
  image:
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-p20dJL6iHq9twkxR6lNGxRwOpUTwKp.png",
},
 
  {
  title: "Treasurer",
  organization: "GAP Society",
  period: "2021 - 2023",
  description:
    "Managed financial records, oversaw budgeting and fund allocation for society events, and ensured transparent reporting of all monetary activities within the organization.",
  icon: <Award className="h-10 w-10 text-primary" />,
  image: "https://scontent.fktm23-1.fna.fbcdn.net/v/t39.30808-6/289938442_105708102190189_8266136706212290754_n.jpg?_nc_cat=109&ccb=1-7&_nc_sid=6ee11a&_nc_ohc=ilMAmSr0YrQQ7kNvwGDOXt7&_nc_oc=Adluj-ZIZ1YWL9l7uuDMXnEbl_jWBkyLjXRo5jmOBafkF51Q4-2SaKSI1v2zh7-K5BE&_nc_zt=23&_nc_ht=scontent.fktm23-1.fna&_nc_gid=qYY8HKjwN025xk5k2DN4hA&oh=00_AfKv34gRIV4SSkGuw6fOg6X-ubFK0f5Mb-se1FECVdSpvA&oe=682AA952",
}
,
]

interface LeadershipProps {
  inView: boolean
}

export default function Leadership({ inView }: LeadershipProps) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 },
    },
  }

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.5 }}
        className="text-center mb-8"
      >
        <p className="text-muted-foreground max-w-2xl mx-auto">
          My involvement in professional organizations and leadership roles.
        </p>
      </motion.div>

      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate={inView ? "visible" : "hidden"}
        className="grid grid-cols-1 md:grid-cols-3 gap-6"
      >
        {leadershipRoles.map((role, index) => (
          <motion.div key={index} variants={itemVariants}>
            <Card className="h-full overflow-hidden">
              <div className="relative h-48">
                <Image src={role.image || "/placeholder.svg"} alt={role.title} fill className="object-cover" />
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center">{role.icon}</div>
              </div>
              <CardHeader>
                <CardTitle>{role.title}</CardTitle>
                <CardDescription>
                  {role.organization} | {role.period}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{role.description}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>
    </div>
  )
}
