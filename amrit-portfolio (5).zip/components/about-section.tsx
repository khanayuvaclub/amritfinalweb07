"use client"

import { useRef, useEffect, useState } from "react"
import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import Bio from "@/components/about/bio"
import Projects from "@/components/about/projects"
import Skills from "@/components/about/skills"
import Leadership from "@/components/about/leadership"
import Gallery from "@/components/about/gallery"
import { User, Code, GraduationCap, Award, ImageIcon } from "lucide-react"
import { cn } from "@/lib/utils"

const sections = [
  { id: "bio", name: "Bio", icon: <User className="h-5 w-5" /> },
  { id: "projects", name: "Projects", icon: <Code className="h-5 w-5" /> },
  { id: "skills", name: "Skills", icon: <GraduationCap className="h-5 w-5" /> },
  { id: "leadership", name: "Leadership", icon: <Award className="h-5 w-5" /> },
  { id: "gallery", name: "Gallery", icon: <ImageIcon className="h-5 w-5" /> },
]

export default function AboutSection() {
  const [activeSection, setActiveSection] = useState("bio")
  const sectionRefs = useRef<Record<string, HTMLDivElement | null>>({})
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  })

  // Set up intersection observers for each section
  useEffect(() => {
    const observers: IntersectionObserver[] = []
    const options = {
      root: null,
      rootMargin: "0px",
      threshold: 0.3,
    }

    sections.forEach((section) => {
      const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveSection(section.id)
          }
        })
      }, options)

      const element = sectionRefs.current[section.id]
      if (element) {
        observer.observe(element)
        observers.push(observer)
      }
    })

    return () => {
      observers.forEach((observer) => observer.disconnect())
    }
  }, [])

  // Scroll to section when clicking on nav item
  const scrollToSection = (id: string) => {
    const element = sectionRefs.current[id]
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  // Set up refs for each section
  const bioRef = useInView({ threshold: 0.2 })
  const projectsRef = useInView({ threshold: 0.2 })
  const skillsRef = useInView({ threshold: 0.2 })
  const leadershipRef = useInView({ threshold: 0.2 })
  const galleryRef = useInView({ threshold: 0.2 })

  return (
    <>
      {/* Section divider */}
      <div className="section-divider">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" preserveAspectRatio="none">
          <path
            fill="currentColor"
            fillOpacity="0.05"
            d="M0,96L48,112C96,128,192,160,288,186.7C384,213,480,235,576,224C672,213,768,171,864,149.3C960,128,1056,128,1152,149.3C1248,171,1344,213,1392,234.7L1440,256L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
          ></path>
        </svg>
      </div>

      <section id="about" className="pt-16 bg-grid" ref={ref}>
        {/* Page Title */}
        <div className="container py-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7, ease: "easeOut" }}
            className="text-center mb-8"
          >
            <h2 className="text-3xl font-bold mb-4 gradient-text inline-block">About Me</h2>
            <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Learn more about my background, projects, skills, and activities.
            </p>
          </motion.div>
        </div>

        {/* Sticky Navigation */}
        <div className="sticky top-16 z-30 bg-background/90 backdrop-blur-md border-b">
          <div className="container py-4">
            <nav className="flex justify-center overflow-x-auto">
              <ul className="flex space-x-1 md:space-x-2">
                {sections.map((section) => (
                  <li key={section.id}>
                    <button
                      onClick={() => scrollToSection(section.id)}
                      className={cn(
                        "flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-all duration-300",
                        activeSection === section.id
                          ? "bg-primary text-primary-foreground shadow-lg"
                          : "hover:bg-muted",
                      )}
                    >
                      {section.icon}
                      <span className="hidden md:inline">{section.name}</span>
                    </button>
                  </li>
                ))}
              </ul>
            </nav>
          </div>
        </div>

        {/* Bio Section */}
        <div
          id="bio"
          ref={(el) => {
            sectionRefs.current.bio = el
            bioRef.ref(el)
          }}
          className="py-16 bg-muted/30"
        >
          <div className="container">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={bioRef.inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.7, ease: "easeOut" }}
              className="mb-8"
            >
              <h3 className="text-2xl font-bold mb-4">Biography</h3>
              <div className="w-16 h-1 bg-primary mb-6"></div>
            </motion.div>
            <Bio inView={bioRef.inView} />
          </div>
        </div>

        {/* Projects Section */}
        <div
          id="projects"
          ref={(el) => {
            sectionRefs.current.projects = el
            projectsRef.ref(el)
          }}
          className="py-16"
        >
          <div className="container">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={projectsRef.inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.7, ease: "easeOut" }}
              className="mb-8"
            >
              <h3 className="text-2xl font-bold mb-4">Projects</h3>
              <div className="w-16 h-1 bg-primary mb-6"></div>
            </motion.div>
            <Projects inView={projectsRef.inView} />
          </div>
        </div>

        {/* Skills Section */}
        <div
          id="skills"
          ref={(el) => {
            sectionRefs.current.skills = el
            skillsRef.ref(el)
          }}
          className="py-16 bg-muted/30"
        >
          <div className="container">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={skillsRef.inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.7, ease: "easeOut" }}
              className="mb-8"
            >
              <h3 className="text-2xl font-bold mb-4">Skills</h3>
              <div className="w-16 h-1 bg-primary mb-6"></div>
            </motion.div>
            <Skills inView={skillsRef.inView} />
          </div>
        </div>

        {/* Leadership Section */}
        <div
          id="leadership"
          ref={(el) => {
            sectionRefs.current.leadership = el
            leadershipRef.ref(el)
          }}
          className="py-16"
        >
          <div className="container">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={leadershipRef.inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.7, ease: "easeOut" }}
              className="mb-8"
            >
              <h3 className="text-2xl font-bold mb-4">Leadership & Activities</h3>
              <div className="w-16 h-1 bg-primary mb-6"></div>
            </motion.div>
            <Leadership inView={leadershipRef.inView} />
          </div>
        </div>

        {/* Gallery Section */}
        <div
          id="gallery"
          ref={(el) => {
            sectionRefs.current.gallery = el
            galleryRef.ref(el)
          }}
          className="py-16 bg-muted/30"
        >
          <div className="container">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={galleryRef.inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.7, ease: "easeOut" }}
              className="mb-8"
            >
              <h3 className="text-2xl font-bold mb-4">Gallery</h3>
              <div className="w-16 h-1 bg-primary mb-6"></div>
            </motion.div>
            <Gallery inView={galleryRef.inView} />
          </div>
        </div>
      </section>
    </>
  )
}
