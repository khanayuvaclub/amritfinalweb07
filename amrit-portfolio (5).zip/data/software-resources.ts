export const softwareResources = [
  {
    id: "python",
    name: "Python",
    description:
      "A versatile programming language widely used in chemical engineering for data analysis, modeling, and simulation.",
    whyLearn:
      "Python has become an essential tool for chemical engineers due to its simplicity, versatility, and powerful libraries for scientific computing, data analysis, and machine learning.",
    applications: [
      "Process simulation and optimization",
      "Data analysis of experimental results",
      "Machine learning for predictive modeling",
      "Automation of repetitive calculations",
      "Creating interactive visualizations of chemical processes",
    ],
    resources: [
      {
        type: "book",
        name: "Python Books Collection",
        description: "A comprehensive collection of Python books for chemical engineers.",
        link: "https://drive.google.com/drive/folders/1JAjsAsDgxq9bYrJ-1RDsxonDdg770NZ1?usp=sharing",
      },
      {
        type: "download",
        name: "Python Workshop Materials",
        description: "Workshop materials for learning Python in chemical engineering.",
        link: "https://drive.google.com/drive/folders/1ti5e3lslMOH9tMCvz2zwDsc1PgJ17VfR?usp=drive_link",
      },
      {
        type: "video",
        name: "Python Tutorial - Part 1",
        description: "Video tutorial on Python basics for chemical engineers.",
        link: "https://youtu.be/nLRL_NcnK-4?si=8_LLRG-fky_urLpt",
      },
      {
        type: "video",
        name: "Python Tutorial - Part 2",
        description: "Advanced Python concepts for chemical engineering applications.",
        link: "https://youtube.com/playlist?list=PLkdGijFCNuVnGxo-1fSNcdHh5gZc17oRM&si=gTGTdYXIk9tuvTPH",
      },
      {
        type: "video",
        name: "TensorFlow Tutorial - Part 1",
        description: "Introduction to TensorFlow for machine learning in chemical engineering.",
        link: "https://youtu.be/tpCFfeUEGs8?si=dmt1aNF4zOxdLOzN",
      },
      {
        type: "video",
        name: "TensorFlow Tutorial - Part 2",
        description: "Advanced TensorFlow applications in chemical engineering.",
        link: "https://youtu.be/ZUKz4125WNI?si=Ngt0cLHgjqHPTbl2",
      },
    ],
  },
  {
    id: "aspen",
    name: "Aspen",
    description: "Industry-standard process simulation software for chemical engineering design and optimization.",
    whyLearn:
      "Aspen is the industry standard for process simulation and is used by chemical engineers worldwide for process design, optimization, and troubleshooting. Proficiency in Aspen is highly valued by employers in the chemical industry.",
    applications: [
      "Process flowsheet development and simulation",
      "Equipment sizing and design",
      "Process optimization and sensitivity analysis",
      "Economic evaluation of chemical processes",
      "Thermodynamic property estimation",
    ],
    resources: [
      {
        type: "download",
        name: "Aspen Plus and Aspen Hysys",
        description: "Download links for Aspen Plus and Aspen Hysys software.",
        link: "https://drive.google.com/drive/folders/1C1MFLmITZAPii0MB2HiIy5GMZO1bYJF3?usp=sharing",
      },
      {
        type: "book",
        name: "Aspen Book 1",
        description: "Comprehensive guide to using Aspen for chemical process simulation.",
        link: "https://drive.google.com/file/d/1LpqeZZgpAGKJGDUg_REG0SXTLTdKdcX0/view?usp=sharing",
      },
      {
        type: "book",
        name: "Aspen Book 2",
        description: "Advanced techniques and applications of Aspen in chemical engineering.",
        link: "https://drive.google.com/file/d/1Y86CKZvgLNmys5WVZO16gyJoOr37A7sd/view?usp=sharing",
      },
      {
        type: "video",
        name: "Aspen Tutorial Playlist 1",
        description: "Video tutorials for learning Aspen Plus and Aspen Hysys.",
        link: "https://youtube.com/playlist?list=PLwdnzlV3ogoWmaPmHqavPktjRTvXcZxb7&si=uG4Cr4utOF24NsDM",
      },
      {
        type: "video",
        name: "Aspen Tutorial Playlist 2",
        description: "Advanced Aspen tutorials for chemical engineering applications.",
        link: "https://youtube.com/playlist?list=PLgW2fMtaFzDXaQ9Qd9cjL6wgWeX1lcHRi&si=Iu6-APXTNlk8AIRm",
      },
    ],
  },
  {
    id: "matlab",
    name: "MATLAB",
    description:
      "A powerful numerical computing environment used for algorithm development, data analysis, and visualization.",
    whyLearn:
      "MATLAB is widely used in chemical engineering for numerical analysis, modeling, and simulation. Its powerful built-in functions and visualization capabilities make it ideal for solving complex engineering problems.",
    applications: [
      "Numerical solution of differential equations",
      "Process modeling and simulation",
      "Data analysis and visualization",
      "Control system design and analysis",
      "Optimization of chemical processes",
    ],
    resources: [
      {
        type: "book",
        name: "Chemical Engineering Computing",
        description: "Guide to using MATLAB for chemical engineering applications.",
        link: "https://drive.google.com/file/d/1R2ZEjT0LSmeGLsWY0dzk7srHuyMBKwlA/view?usp=sharing",
      },
      {
        type: "book",
        name: "Software For Chemical Engineering",
        description: "Comprehensive guide to software tools including MATLAB for chemical engineers.",
        link: "https://drive.google.com/file/d/1LwimqmOpwvv2OG43d0DHpmAuIJwSmqF4/view?usp=sharing",
      },
    ],
  },
  {
    id: "autocad",
    name: "AutoCAD Plant 3D",
    description: "Specialized CAD software for designing and documenting process plants and piping systems.",
    whyLearn:
      "AutoCAD Plant 3D is essential for creating detailed piping and instrumentation diagrams (P&IDs) and 3D models of chemical plants. It's a valuable skill for chemical engineers involved in plant design and layout.",
    applications: [
      "Creating piping and instrumentation diagrams (P&IDs)",
      "3D modeling of chemical plants and equipment",
      "Generating isometric drawings for piping systems",
      "Creating equipment layout and arrangement drawings",
      "Producing detailed fabrication and construction drawings",
    ],
    resources: [
      {
        type: "book",
        name: "P&ID Concept Book",
        description: "Comprehensive guide to piping and instrumentation diagrams.",
        link: "https://drive.google.com/file/d/1uFYTqFHwhaBL5vFqy7IYB0OIQBfivrz4/view?usp=sharing",
      },
      {
        type: "book",
        name: "Introduction to Plant 3D Software",
        description: "Getting started with AutoCAD Plant 3D for chemical plant design.",
        link: "https://drive.google.com/file/d/1aK08q-CirbByoNE2FsX_b8y56Rmqgfc3/view?usp=sharing",
      },
    ],
  },
  {
    id: "solidworks",
    name: "SolidWorks",
    description: "3D CAD software used for detailed equipment design and modeling in chemical engineering.",
    whyLearn:
      "SolidWorks allows chemical engineers to create detailed 3D models of equipment and components, perform stress analysis, and generate manufacturing drawings. It's particularly useful for custom equipment design.",
    applications: [
      "Detailed 3D modeling of chemical equipment",
      "Stress and thermal analysis of components",
      "Flow simulation through equipment",
      "Creating assembly drawings for fabrication",
      "Generating detailed manufacturing drawings",
    ],
    resources: [
      {
        type: "book",
        name: "SolidWorks for Chemical Engineers",
        description: "Guide to using SolidWorks for chemical engineering applications.",
        link: "#",
      },
      {
        type: "video",
        name: "SolidWorks Tutorial Series",
        description: "Video tutorials for learning SolidWorks for equipment design.",
        link: "#",
      },
    ],
  },
  {
    id: "polymath",
    name: "Polymath",
    description: "Numerical computation software specifically designed for solving chemical engineering problems.",
    whyLearn:
      "Polymath is a specialized tool for solving systems of equations, differential equations, and regression problems commonly encountered in chemical engineering. It's user-friendly and designed specifically for engineering applications.",
    applications: [
      "Solving systems of nonlinear equations",
      "Numerical integration of differential equations",
      "Regression analysis of experimental data",
      "Parameter estimation for chemical kinetics",
      "Solving mass and energy balance problems",
    ],
    resources: [
      {
        type: "book",
        name: "Polymath for Chemical Engineers",
        description: "Guide to using Polymath for solving chemical engineering problems.",
        link: "#",
      },
      {
        type: "video",
        name: "Polymath Tutorial Series",
        description: "Video tutorials for learning Polymath for numerical computation.",
        link: "#",
      },
    ],
  },
]
