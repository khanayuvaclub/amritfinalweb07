export const semesterMaterials = [
  {
    name: "First Semester",
    resources: [
      {
        name: "First Semester (Old Curriculum)",
        link: "https://drive.google.com/drive/folders/1EVD9f6rW_ik96NSdVetl9mueG97jFgns?usp=sharing",
      },
      {
        name: "First Semester (New Curriculum)",
        link: "https://drive.google.com/drive/folders/1PG9WwAqeb_8huiIVegd66WehU4MJ7V0r?fbclid=IwY2xjawKSPJlleHRuA2FlbQIxMABicmlkETFyWTRIVWpUbjdNN3ZpR2VyAR4Z52Ha7B4Dwp2GhlBvHpIwatL6uM6S4JA39gYdd7n90KAUqQI3tDPRbqFPGA_aem_j_-N5jh_fsLUIOydbcAN_Q",
      },
    ],
  },
  {
    name: "Second Semester",
    resources: [
      {
        name: "Second Semester (Old Curriculum)",
        link: "https://drive.google.com/drive/folders/1RmdSvc2jTAmPGSHW1Ae0dqHrpuiV8zQv?usp=sharing",
      },
      {
        name: "Second Semester (New Curriculum)",
        link: "https://drive.google.com/drive/folders/1eqapi8FnCrvvkilATJJRPCjh5qC60duZ?fbclid=IwY2xjawKSPJlleHRuA2FlbQIxMABicmlkETFyWTRIVWpUbjdNN3ZpR2VyAR4Z52Ha7B4Dwp2GhlBvHpIwatL6uM6S4JA39gYdd7n90KAUqQI3tDPRbqFPGA_aem_j_-N5jh_fsLUIOydbcAN_Q",
      },
    ],
  },
  {
    name: "Third Semester",
    resources: [
      {
        name: "Third Semester (Old Curriculum)",
        link: "https://drive.google.com/drive/folders/1iT3zNv9iS3vIimLXM3r8jvU3y8T-lt8T?usp=sharing",
      },
      {
        name: "Third Semester (New Curriculum)",
        link: "https://drive.google.com/drive/folders/1eqapi8FnCrvvkilATJJRPCjh5qC60duZ?fbclid=IwY2xjawKSPJlleHRuA2FlbQIxMABicmlkETFyWTRIVWpUbjdNN3ZpR2VyAR4Z52Ha7B4Dwp2GhlBvHpIwatL6uM6S4JA39gYdd7n90KAUqQI3tDPRbqFPGA_aem_j_-N5jh_fsLUIOydbcAN_Q",
      },
    ],
  },
  {
    name: "Fourth Semester",
    resources: [
      {
        name: "Fourth Semester (Old Curriculum)",
        link: "https://drive.google.com/drive/folders/1zfJqT2ak4h77Yl-UMXjvGDWekyL1x_sg?usp=sharing",
      },
      {
        name: "Fourth Semester (New Curriculum)",
        link: "https://drive.google.com/drive/folders/1eqapi8FnCrvvkilATJJRPCjh5qC60duZ?fbclid=IwY2xjawKSPJlleHRuA2FlbQIxMABicmlkETFyWTRIVWpUbjdNN3ZpR2VyAR4Z52Ha7B4Dwp2GhlBvHpIwatL6uM6S4JA39gYdd7n90KAUqQI3tDPRbqFPGA_aem_j_-N5jh_fsLUIOydbcAN_Q",
      },
    ],
  },
  {
    name: "Fifth Semester",
    resources: [
      {
        name: "Fifth Semester (Old Curriculum)",
        link: "https://drive.google.com/drive/folders/11Ii89daudscfp3K8CzPrC244hSvBYH2q?usp=sharing",
      },
      {
        name: "Fifth Semester (New Curriculum)",
        link: "https://drive.google.com/drive/folders/1eqapi8FnCrvvkilATJJRPCjh5qC60duZ?fbclid=IwY2xjawKSPJlleHRuA2FlbQIxMABicmlkETFyWTRIVWpUbjdNN3ZpR2VyAR4Z52Ha7B4Dwp2GhlBvHpIwatL6uM6S4JA39gYdd7n90KAUqQI3tDPRbqFPGA_aem_j_-N5jh_fsLUIOydbcAN_Q",
      },
    ],
  },
  {
    name: "Sixth Semester",
    resources: [
      {
        name: "Sixth Semester (Old Curriculum)",
        link: "https://drive.google.com/drive/folders/1fbO_No-Xv_hqBjQnaqePIwhYsKmrCzVT?usp=sharing",
      },
      {
        name: "Sixth Semester (New Curriculum)",
        link: "https://drive.google.com/drive/folders/1eqapi8FnCrvvkilATJJRPCjh5qC60duZ?fbclid=IwY2xjawKSPJlleHRuA2FlbQIxMABicmlkETFyWTRIVWpUbjdNN3ZpR2VyAR4Z52Ha7B4Dwp2GhlBvHpIwatL6uM6S4JA39gYdd7n90KAUqQI3tDPRbqFPGA_aem_j_-N5jh_fsLUIOydbcAN_Q",
      },
    ],
  },
  {
    name: "Seventh Semester",
    resources: [
      {
        name: "Seventh Semester (Old Curriculum)",
        link: "https://drive.google.com/drive/folders/1dxAjcQLPrG0qbpBHxv7qG7TMLS4e1cXC?usp=sharing",
      },
      {
        name: "Seventh Semester (New Curriculum)",
        link: "https://drive.google.com/drive/folders/1eqapi8FnCrvvkilATJJRPCjh5qC60duZ?fbclid=IwY2xjawKSPJlleHRuA2FlbQIxMABicmlkETFyWTRIVWpUbjdNN3ZpR2VyAR4Z52Ha7B4Dwp2GhlBvHpIwatL6uM6S4JA39gYdd7n90KAUqQI3tDPRbqFPGA_aem_j_-N5jh_fsLUIOydbcAN_Q",
      },
    ],
  },
  {
    name: "Eighth Semester",
    resources: [
      {
        name: "Eighth Semester (Old Curriculum)",
        link: "https://drive.google.com/drive/folders/1A3wtP2BB5BTG5-nei-bOHzK5ROhQ_5Id?usp=sharing",
      },
      {
        name: "Eighth Semester (New Curriculum)",
        link: "https://drive.google.com/drive/folders/1eqapi8FnCrvvkilATJJRPCjh5qC60duZ?fbclid=IwY2xjawKSPJlleHRuA2FlbQIxMABicmlkETFyWTRIVWpUbjdNN3ZpR2VyAR4Z52Ha7B4Dwp2GhlBvHpIwatL6uM6S4JA39gYdd7n90KAUqQI3tDPRbqFPGA_aem_j_-N5jh_fsLUIOydbcAN_Q",
      },
    ],
  },
]
