import AspenPage from "@/components/materials/aspen-page"

export default function Aspen() {
  return <AspenPage />
}
