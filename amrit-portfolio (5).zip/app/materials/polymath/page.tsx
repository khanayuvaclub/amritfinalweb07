import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function Polymath() {
  return (
    <main className="pt-20 pb-16">
      <div className="container">
        <div className="mb-8">
          <Button variant="ghost" asChild className="mb-4">
            <Link href="/materials" className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Materials
            </Link>
          </Button>

          <div className="text-center mb-12">
            <h1 className="text-3xl font-bold mb-4">Polymath Resources</h1>
            <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Resources for learning and applying Polymath in chemical engineering problem-solving.
            </p>
          </div>
        </div>

        <div className="text-center p-8 border rounded-lg">
          <h3 className="text-lg font-medium mb-4">Coming Soon</h3>
          <p className="text-muted-foreground">
            Polymath resources are currently being compiled and will be available soon.
          </p>
        </div>
      </div>
    </main>
  )
}
