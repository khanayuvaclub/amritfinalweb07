import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function Matlab() {
  return (
    <main className="pt-20 pb-16">
      <div className="container">
        <div className="mb-8">
          <Button variant="ghost" asChild className="mb-4">
            <Link href="/materials" className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Materials
            </Link>
          </Button>

          <div className="text-center mb-12">
            <h1 className="text-3xl font-bold mb-4">MATLAB Resources</h1>
            <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Resources for learning and applying MATLAB in chemical engineering applications.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-6 border rounded-lg">
            <h3 className="text-lg font-medium mb-4">Chemical Engineering Computing</h3>
            <p className="text-muted-foreground mb-4">Guide to using MATLAB for chemical engineering applications.</p>
            <Button asChild>
              <a
                href="https://drive.google.com/file/d/1R2ZEjT0LSmeGLsWY0dzk7srHuyMBKwlA/view?usp=sharing"
                target="_blank"
                rel="noopener noreferrer"
              >
                Access Resource
              </a>
            </Button>
          </div>

          <div className="p-6 border rounded-lg">
            <h3 className="text-lg font-medium mb-4">Software For Chemical Engineering</h3>
            <p className="text-muted-foreground mb-4">
              Comprehensive guide to software tools including MATLAB for chemical engineers.
            </p>
            <Button asChild>
              <a
                href="https://drive.google.com/file/d/1LwimqmOpwvv2OG43d0DHpmAuIJwSmqF4/view?usp=sharing"
                target="_blank"
                rel="noopener noreferrer"
              >
                Access Resource
              </a>
            </Button>
          </div>
        </div>
      </div>
    </main>
  )
}
