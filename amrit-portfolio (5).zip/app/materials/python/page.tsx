import PythonPage from "@/components/materials/python-page"

export default function Python() {
  return <PythonPage />
}
