import SemesterPage from "@/components/materials/semester-page"

export default function Semester() {
  return <SemesterPage />
}
