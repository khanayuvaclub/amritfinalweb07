import BooksPage from "@/components/materials/books-page"

export default function Books() {
  return <BooksPage />
}
