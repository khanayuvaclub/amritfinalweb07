import EngineeringMaterials from "@/components/engineering-materials"

export default function MaterialsPage() {
  return <EngineeringMaterials />
}
