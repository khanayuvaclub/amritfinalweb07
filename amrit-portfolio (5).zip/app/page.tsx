import Hero from "@/components/hero"
import AboutSection from "@/components/about-section"
import Blog from "@/components/blog"
import Contact from "@/components/contact"
import MaterialsHighlight from "@/components/materials-highlight"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Hero />
      <AboutSection />
      <Blog />
      <MaterialsHighlight />
      <Contact />
    </main>
  )
}
